const {
  Feedback,
  Employee,
  Sector,
  Division,
  Department,
  Team,
  PublicFeedback,
} = require('../models');
const { validateLanguage, getSentiment, addProfilePictureUrl } = require('../utils/helpers');
const { Op } = require('sequelize');

// Create feedback
const createFeedback = async (req, res) => {
  try {
    const {
      full_name,
      phone_number,
      subcity,
      sector_id,
      division_id,
      department_id,
      team_id,
      employee_id,
      comment,
      rating,
      lang,
      description,
    } = req.body;
    //
    // if (!validateLanguage(lang)) {
    //   return res
    //     .status(400)
    //     .json({ message: "Invalid language. Use en, am, or af." });
    // }
    if (!phone_number || !section || !comment) {
      return res.status(400).json({ message: 'Phone number, section, and comment are required' });
    }
    if (rating && ![1, 2, 3, 4, 5].includes(Number(rating))) {
      return res.status(400).json({ message: 'Rating must be between 1 and 5' });
    }

    const feedbackData = {
      full_name,
      phone_number,
      subcity,
      sector_id,
      division_id,
      department_id,
      team_id,
      employee_id: employee_id,
      description,
      [`comment_${lang}`]: comment,
    };

    const feedback = await Feedback.create(feedbackData);

    let employeeDetails = null;
    if (employee_id) {
      const employee = await Employee.findByPk(employee_id, {
        attributes: [
          'id',
          [`first_name_${lang}`, 'first_name'],
          [`middle_name_${lang}`, 'middle_name'],
          [`last_name_${lang}`, 'last_name'],
          'office_number',
          'floor_number',
          [`position_${lang}`, 'position'],
          [`department_${lang}`, 'department'],
          'section',
          'profile_picture',
        ],
      });
      employeeDetails = employee ? addProfilePictureUrl(employee) : null;
    }

    res.status(201).json({
      message: 'Feedback submitted successfully',
      feedback: {
        id: feedback.id,
        full_name: feedback.full_name,
        phone_number: feedback.phone_number,
        section: feedback.section,
        department_id: feedback.department,
        employee_id: feedback.employee_id,
        comment: feedback[`comment_${lang}`],
        rating: feedback.rating,
        sentiment: getSentiment(feedback.rating),
        created_at: feedback.created_at,
        employee: employeeDetails,
      },
    });
  } catch (error) {
    console.error('Error submitting feedback:', error);
    res.status(500).json({ message: 'Error submitting feedback', error: error.message });
  }
};

// Get feedback for admin
const getFeedbackAdmin = async (req, res) => {
  try {
    const { lang = 'en', date_from, date_to, section, department } = req.query;
    const admin = req.user;

    // if (!validateLanguage(lang)) {
    //   return res
    //     .status(400)
    //     .json({ message: "Invalid language. Use en, am, or af." });
    // }
    //
    const where = {};
    if (admin.role === 'Admin') {
      where.department = admin.department;
    } else if (admin.role === 'SubCityAdmin') {
      where.section = admin.section;
    }
    if (section && admin.role === 'SuperAdmin') where.section = section;
    if (department && admin.role === 'SuperAdmin') where.department = department;
    if (date_from && date_to) {
      where.created_at = {
        [Op.between]: [new Date(date_from), new Date(date_to)],
      };
    }

    const feedback = await PublicFeedback.findAll({
      where,
      attributes: [
        'id',
        'phone_number',
        'subcity',
        'department_id',
        'employee_id',
        'sector_id',
        'division_id',
        'team_id',
        'feedback_text',
        'admin_response',
        // "rating",
        'feedback_source',
        'created_at',
      ],
      include: [
        {
          model: Sector,
          as: 'sector',
          attributes: ['id', 'name_en', 'name_am', 'name_af'],
        },
        {
          model: Division,
          as: 'division',
          attributes: ['id', 'name_en', 'name_am', 'name_af', 'sector_id'],
        },
        {
          model: Department,
          as: 'department',
          attributes: ['id', 'name_en', 'name_am', 'name_af', 'division_id'],
        },
        {
          model: Team,
          as: 'team',
          attributes: [
            'id',
            'name_en',
            'name_am',
            'name_af',
            'sector_id',
            'department_id',
            'division_id',
          ],
        },
        {
          model: Employee,
          as: 'employee',
          attributes: [
            'id',
            [`first_name_${lang}`, 'first_name'],
            [`middle_name_${lang}`, 'middle_name'],
            [`last_name_${lang}`, 'last_name'],
            'office_number',
            'floor_number',
            [`position_${lang}`, 'position'],
            'department_id',
            'section',
            'profile_picture',
          ],
        },
      ],
      order: [['created_at', 'DESC']],
    });

    const feedbackWithUrls = feedback.map((fb) => ({
      ...fb.get({ plain: true }),
      sentiment: getSentiment(fb.rating),
      employee: fb.employee ? addProfilePictureUrl(fb.employee) : null,
    }));

    res.json(feedbackWithUrls);
  } catch (error) {
    console.error('Error fetching feedback:', error);
    res.status(500).json({ message: 'Error fetching feedback', error: error.message });
  }
};
module.exports = {
  createFeedback,
  getFeedbackAdmin,
};
